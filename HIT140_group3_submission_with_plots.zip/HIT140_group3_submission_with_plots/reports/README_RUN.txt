To reproduce main analysis:
1) Create venv and install requirements: pip install -r requirements.txt
2) From project root run: python src/analysis.py
Outputs will be in reports/appendix/ and figures in reports/figures/.
